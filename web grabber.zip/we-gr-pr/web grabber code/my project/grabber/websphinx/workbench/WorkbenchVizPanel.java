// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2009 12:16:06 PM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Workbench.java

package websphinx.workbench;

import java.awt.Button;
import java.awt.Component;
import rcm.awt.TabPanel;

// Referenced classes of package websphinx.workbench:
//            Workbench

class WorkbenchVizPanel extends TabPanel
{

    public WorkbenchVizPanel(Workbench workbench)
    {
        this.workbench = workbench;
    }

    public void select(int num)
    {
        Component prior = getSelectedComponent();
        super.select(num);
        Component now = getSelectedComponent();
        if(prior == now)
            return;
        if(prior != null)
            workbench.hideVisualization(prior);
        if(now != null)
        {
            workbench.showVisualization(now);
            now.requestFocus();
        }
    }

    Workbench workbench;
    Button optionsButton;
    Button tearoffButton;
}