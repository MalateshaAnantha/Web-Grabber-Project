// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2009 12:14:59 PM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Workbench.java

package websphinx.workbench;

import java.awt.Event;
import rcm.awt.ClosableFrame;

// Referenced classes of package websphinx.workbench:
//            Workbench

class WorkbenchFrame extends ClosableFrame
{

    public WorkbenchFrame(Workbench workbench)
    {
        this.workbench = workbench;
    }

    public void close()
    {
        workbench.close();
    }

    public boolean handleEvent(Event event)
    {
        if(workbench.doEvent(event))
            return true;
        else
            return super.handleEvent(event);
    }

    Workbench workbench;
}