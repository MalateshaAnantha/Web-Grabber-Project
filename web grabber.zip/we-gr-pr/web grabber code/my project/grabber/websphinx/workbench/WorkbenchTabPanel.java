// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2009 12:15:33 PM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Workbench.java

package websphinx.workbench;

import java.awt.Button;
import rcm.awt.TabPanel;

class WorkbenchTabPanel extends TabPanel
{

    public WorkbenchTabPanel()
    {
       // add(advancedButton = new Button("Advanced"));
    }

    Button advancedButton;
}