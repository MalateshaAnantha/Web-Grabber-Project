// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2009 12:14:48 PM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   WorkbenchControlPanel.java

package websphinx.workbench;

import java.awt.*;
import rcm.awt.Constrain;
import rcm.awt.PopupDialog;
import rcm.util.Win;

// Referenced classes of package websphinx.workbench:
//            WebGraph, WebOutline

public class WorkbenchControlPanel extends PopupDialog
{

    public WorkbenchControlPanel(WebGraph g, WebOutline o)
    {
        super(Win.findFrame(((java.awt.Component) (g == null ? ((java.awt.Component) (o)) : ((java.awt.Component) (g))))), "Workbench Control Panel", true);
        this.g = g;
        this.o = o;
        setLayout(new GridBagLayout());
        Constrain.add(this, new Label("Display:"), Constrain.labelLike(0, 0));
        Constrain.add(this, nodeChoice = new Choice(), Constrain.fieldLike(1, 0));
        nodeChoice.addItem("icons");
        nodeChoice.addItem("titles");
        nodeChoice.addItem("absolute URLs");
        nodeChoice.addItem("relative URLs");
        nodeChoice.select(g == null ? o.defaultRendering + 1 : g.defaultRendering);
        Constrain.add(this, new Label("Pages:"), Constrain.labelLike(0, 1));
        Constrain.add(this, pageChoice = new Choice(), Constrain.fieldLike(1, 1));
        pageChoice.addItem("visited pages");
        pageChoice.addItem("all pages");
        Constrain.add(this, new Label("Links:"), Constrain.labelLike(0, 2));
        Constrain.add(this, linkChoice = new Choice(), Constrain.fieldLike(1, 2));
        linkChoice.addItem("tree links");
        linkChoice.addItem("all links");
        if(g != null)
        {
            switch(g.defaultFilter)
            {
            case 0: // '\0'
            case 1: // '\001'
                pageChoice.select(0);
                linkChoice.select(0);
                break;

            case 2: // '\002'
            case 3: // '\003'
                pageChoice.select(1);
                linkChoice.select(0);
                break;

            case 4: // '\004'
                pageChoice.select(1);
                linkChoice.select(1);
                break;
            }
        } else
        {
            pageChoice.select(o.defaultFilter != 4 ? 0 : 1);
            linkChoice.disable();
        }
        Constrain.add(this, automatic = new Checkbox("Automatic layout"), Constrain.labelLike(1, 3));
        if(g != null)
            automatic.setState(g.getAutomaticLayout());
        else
            g.disable();
        Panel panel;
        Constrain.add(this, panel = new Panel(), Constrain.centered(Constrain.labelLike(0, 4, 2)));
        panel.add(applyButton = new Button("Apply"));
        panel.add(okButton = new Button("OK"));
        panel.add(cancelButton = new Button("Cancel"));
        pack();
    }

    void writeBack()
    {
        if(g != null)
            g.setAutomaticLayout(automatic.getState());
        switch(nodeChoice.getSelectedIndex())
        {
        case 0: // '\0'
            if(g != null)
                g.setNodeRendering(0);
            if(o != null)
                o.setNodeRendering(0);
            break;

        case 1: // '\001'
            if(g != null)
                g.setNodeRendering(1);
            if(o != null)
                o.setNodeRendering(0);
            break;

        case 2: // '\002'
            if(g != null)
                g.setNodeRendering(2);
            if(o != null)
                o.setNodeRendering(1);
            break;

        case 3: // '\003'
            if(g != null)
                g.setNodeRendering(3);
            if(o != null)
                o.setNodeRendering(2);
            break;
        }
label0:
        switch(pageChoice.getSelectedIndex())
        {
        default:
            break;

        case 0: // '\0'
            if(g != null)
                g.setLinkFilter(1);
            if(o != null)
                o.setLinkFilter(1);
            break;

        case 1: // '\001'
            if(o != null)
                o.setLinkFilter(2);
            switch(linkChoice.getSelectedIndex())
            {
            default:
                break label0;

            case 0: // '\0'
                if(g != null)
                    g.setLinkFilter(2);
                break label0;

            case 1: // '\001'
                break;
            }
            if(g != null)
                g.setLinkFilter(4);
            break;
        }
    }

    public boolean handleEvent(Event event)
    {
        if(event.id == 1001)
        {
            if(event.target == applyButton)
                writeBack();
            else
            if(event.target == okButton)
            {
                writeBack();
                close();
            } else
            if(event.target == cancelButton)
                close();
            else
                return super.handleEvent(event);
        } else
        if(event.id == 201)
            dispose();
        else
            return super.handleEvent(event);
        return true;
    }

    WebGraph g;
    WebOutline o;
    Choice nodeChoice;
    Choice pageChoice;
    Choice linkChoice;
    Checkbox automatic;
    Button applyButton;
    Button okButton;
    Button cancelButton;
}