// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   GraphNode.java

package graph;


// Referenced classes of package graph:
//            Node, Barycenter

public class GraphNode extends Node {

            public Barycenter barycenter;


            public GraphNode(String s) {
/*   8*/        super(s);
            }

            public GraphNode(String s, int i, int j) {
/*  10*/        super(s, i, j);
            }

            public GraphNode(Node node) {
/*  13*/        super(node);
/*  14*/        if (node instanceof GraphNode) {
/*  15*/            barycenter = ((GraphNode)node).barycenter;
                }
            }

            public GraphNode(Barycenter barycenter1) {
/*  18*/        barycenter = barycenter1;
            }

            public GraphNode(String s, Barycenter barycenter1) {
/*  20*/        super(s);
/*  20*/        barycenter = barycenter1;
            }

            public GraphNode(String s, int i, int j, Barycenter barycenter1) {
/*  23*/        super(s, i, j);
/*  23*/        barycenter = barycenter1;
            }

            public GraphNode(Node node, Barycenter barycenter1) {
/*  25*/        super(node);
/*  25*/        barycenter = barycenter1;
            }
}
