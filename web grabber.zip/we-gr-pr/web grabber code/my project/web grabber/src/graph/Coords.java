// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   Coords.java

package graph;


public final class Coords {

            public double x;
            public double y;

            public Coords(double d, double d1) {
/*   5*/        x = d;
/*   5*/        y = d1;
            }

            public Coords add(Coords coords) {
/*   6*/        x += coords.x;
/*   6*/        y += coords.y;
/*   6*/        return coords;
            }
}
