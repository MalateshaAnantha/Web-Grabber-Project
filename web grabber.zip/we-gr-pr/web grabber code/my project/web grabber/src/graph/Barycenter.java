// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   Barycenter.java

package graph;


// Referenced classes of package graph:
//            Edge, Node

public class Barycenter {

            public double x;
            public double y;
            public double width;
            public double height;
            public double degree;
            public Barycenter NW;
            public Barycenter NE;
            public Barycenter SW;
            public Barycenter SE;
            public Barycenter parent;
            public Node nodes[];
            public int sizeNodes;
            public Edge edges[];
            public int sizeEdges;
            private int allocatedNodes;
            private int allocatedEdges;

            private void doubleNodeArray() {
/*  13*/        Node anode[] = new Node[allocatedNodes * 2];
/*  14*/        for (int i = 0; i < allocatedNodes; i++) {
/*  14*/            anode[i] = nodes[i];
                }

/*  15*/        nodes = anode;
/*  15*/        allocatedNodes = allocatedNodes * 2;
            }

            private void doubleEdgeArray() {
/*  20*/        Edge aedge[] = new Edge[allocatedEdges * 2];
/*  21*/        for (int i = 0; i < allocatedEdges; i++) {
/*  21*/            aedge[i] = edges[i];
                }

/*  22*/        edges = aedge;
/*  22*/        allocatedEdges = allocatedEdges * 2;
            }

            public Barycenter() {
/*   8*/        nodes = new Node[1];
/*   9*/        edges = new Edge[1];
/*  11*/        allocatedNodes = 1;
/*  18*/        allocatedEdges = 1;
            }

            public Barycenter(Barycenter barycenter) {
/*   8*/        nodes = new Node[1];
/*   9*/        edges = new Edge[1];
/*  11*/        allocatedNodes = 1;
/*  18*/        allocatedEdges = 1;
/*  27*/        parent = barycenter;
            }

            public synchronized void addNode(Node node) {
/*  30*/        if (sizeNodes == allocatedNodes) {
/*  30*/            doubleNodeArray();
                }
/*  31*/        nodes[sizeNodes++] = node;
/*  32*/        x = (x * (double)(sizeNodes - 1) + node.x) / (double)sizeNodes;
/*  33*/        y = (y * (double)(sizeNodes - 1) + node.y) / (double)sizeNodes;
/*  34*/        width = (width * (double)(sizeNodes - 1) + (double)node.width) / (double)sizeNodes;
/*  35*/        height = (height * (double)(sizeNodes - 1) + (double)node.height) / (double)sizeNodes;
/*  36*/        degree = (degree * (double)(sizeNodes - 1) + (double)node.degree) / (double)sizeNodes;
/*  37*/        node.barycenter = this;
            }

            public synchronized void addEdge(Edge edge) {
/*  41*/        if (sizeEdges == allocatedEdges) {
/*  41*/            doubleEdgeArray();
                }
/*  42*/        edges[sizeEdges++] = edge;
            }

            public synchronized void moveNode(Node node, double d, double d1) {
/*  46*/        x += (d - node.x) / (double)sizeNodes;
/*  47*/        y += (d1 - node.y) / (double)sizeNodes;
/*  48*/        if (parent != null) {
/*  48*/            parent.moveNode(node, d, d1);
                }
            }

            public synchronized void removeNode(Node node) {
/*  52*/        if (sizeNodes == 1) {
/*  52*/            x = 0.0D;
/*  52*/            y = 0.0D;
                } else {
/*  54*/            x = (x * (double)sizeNodes - node.x) / (double)(sizeNodes - 1);
/*  55*/            y = (y * (double)sizeNodes - node.y) / (double)(sizeNodes - 1);
/*  56*/            width = (width * (double)sizeNodes - (double)node.width) / (double)(sizeNodes - 1);
/*  57*/            height = (height * (double)sizeNodes - (double)node.height) / (double)(sizeNodes - 1);
/*  58*/            degree = (degree * (double)sizeNodes - (double)node.degree) / (double)(sizeNodes - 1);
                }
/*  60*/        for (int i = 0; i < sizeNodes; i++) {
/*  61*/            if (nodes[i] != node) {
/*  61*/                continue;
                    }
/*  61*/            nodes[i] = nodes[--sizeNodes];
/*  61*/            break;
                }

/*  62*/        for (int j = 0; j < sizeEdges; j++) {
/*  63*/            Edge edge = edges[j];
/*  64*/            if (edge.from == node || edge.to == node) {
/*  64*/                edges[j] = edges[--sizeEdges];
                    }
                }

/*  66*/        if (parent != null) {
/*  66*/            parent.removeNode(node);
                }
            }

            public synchronized void translate(double d, double d1) {
/*  70*/        for (int i = 0; i < sizeNodes; i++) {
/*  71*/            Node node = nodes[i];
/*  71*/            node.x += d;
/*  71*/            node.y += d1;
                }

/*  73*/        for (Barycenter barycenter = this; barycenter != null; barycenter = barycenter.parent) {
/*  74*/            barycenter.x += (d * (double)sizeNodes) / (double)barycenter.sizeNodes;
/*  75*/            barycenter.y += (d1 * (double)sizeNodes) / (double)barycenter.sizeNodes;
                }

/*  77*/        translateDescendants(this, d, d1);
            }

            private synchronized void translateDescendants(Barycenter barycenter, double d, double d1) {
/*  82*/        if (barycenter.NW != null) {
/*  83*/            barycenter.NW.x += d;
/*  83*/            barycenter.NW.y += d1;
/*  83*/            translateDescendants(barycenter.NW, d, d1);
                }
/*  85*/        if (barycenter.NE != null) {
/*  86*/            barycenter.NE.x += d;
/*  86*/            barycenter.NE.y += d1;
/*  86*/            translateDescendants(barycenter.NE, d, d1);
                }
/*  88*/        if (barycenter.SW != null) {
/*  89*/            barycenter.SW.x += d;
/*  89*/            barycenter.SW.y += d1;
/*  89*/            translateDescendants(barycenter.SW, d, d1);
                }
/*  91*/        if (barycenter.SE != null) {
/*  92*/            barycenter.SE.x += d;
/*  92*/            barycenter.SE.y += d1;
/*  92*/            translateDescendants(barycenter.SE, d, d1);
                }
            }
}
