// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   Graph.java

package graph;


// Referenced classes of package graph:
//            Barycenter, Edge, Node

public final class Graph {

            public int sizeNodes;
            public int sizeEdges;
            public Node nodes[];
            public Edge edges[];
            public Barycenter barycenter;
            private int allocatedNodes;
            private int allocatedEdges;
            private static int DEFAULT_NODE_ALLOC = 100;
            private static int DEFAULT_EDGE_ALLOC = 100;

            public Graph() {
/*  13*/        barycenter = new Barycenter();
/*  19*/        nodes = new Node[allocatedNodes = DEFAULT_NODE_ALLOC];
/*  20*/        edges = new Edge[allocatedEdges = DEFAULT_EDGE_ALLOC];
            }

            public boolean member(Node node) {
/*  26*/        for (int i = 0; i < sizeNodes; i++) {
/*  27*/            if (nodes[i] == node) {
/*  27*/                return true;
                    }
                }

/*  28*/        return false;
            }

            public boolean member(Edge edge) {
/*  32*/        if (edge == null || edge.from == null || edge.to == null) {
/*  33*/            return false;
                }
/*  34*/        for (int i = 0; i < edge.from.degree; i++) {
/*  35*/            if (edge.from.incidentEdges[i] == edge) {
/*  35*/                return true;
                    }
                }

/*  36*/        return false;
            }

            public Node findNode(String s) {
/*  40*/        for (int i = 0; i < sizeNodes; i++) {
/*  41*/            if (nodes[i].name.equals(s)) {
/*  41*/                return nodes[i];
                    }
                }

/*  42*/        return null;
            }

            public Edge findEdge(Node node, Node node1) {
/*  46*/        if (node == null || node1 == null) {
/*  46*/            return null;
                }
/*  47*/        for (int i = 0; i < node.degree; i++) {
/*  48*/            if (node.neighbors[i] == node1) {
/*  48*/                return node.incidentEdges[i];
                    }
                }

/*  49*/        return null;
            }

            public Edge findEdge(String s, String s1) {
/*  53*/        return findEdge(findNode(s), findNode(s1));
            }

            public Node addNode(Node node) {
/*  57*/        if (member(node)) {
/*  57*/            return node;
                }
/*  58*/        if (sizeNodes == allocatedNodes) {
/*  58*/            doubleNodeArray();
                }
/*  59*/        barycenter.addNode(node);
/*  60*/        return nodes[sizeNodes++] = node;
            }

            public Node addNode() {
/*  63*/        return addNode(new Node());
            }

            public Node addNode(String s) {
/*  66*/        Node node = findNode(s);
/*  66*/        if (node != null) {
/*  66*/            return node;
                } else {
/*  67*/            return addNode(new Node(s, barycenter));
                }
            }

            public synchronized void placeNode(Node node, double d, double d1) {
/*  71*/        if (!node.placed) {
/*  72*/            node.placed = true;
/*  72*/            node.x = d;
/*  72*/            node.y = d1;
/*  73*/            barycenter.addNode(node);
/*  71*/            return;
                } else {
/*  75*/            node.barycenter.moveNode(node, d, d1);
/*  75*/            node.x = d;
/*  75*/            node.y = d1;
/*  70*/            return;
                }
            }

            public void placeNode(String s, double d, double d1) {
/*  79*/        Node node = findNode(s);
/*  80*/        if (node != null) {
/*  80*/            placeNode(node, d, d1);
                }
            }

            public void unplaceNode(Node node) {
/*  84*/        if (node.placed) {
/*  84*/            node.barycenter.removeNode(node);
                }
/*  85*/        node.placed = false;
            }

            public void unplaceNode(String s) {
/*  89*/        Node node = findNode(s);
/*  89*/        if (node != null) {
/*  89*/            unplaceNode(node);
                }
            }

            public void removeNode(Node node) {
/*  93*/        for (int i = 0; i < node.degree; i++) {
/*  94*/            node.neighbors[i].removeNeighbor(node);
                }

/*  95*/        for (int j = 0; j < node.degree; j++) {
/*  96*/            for (int k = 0; k < sizeEdges; k++) {
/*  97*/                if (edges[k] != node.incidentEdges[j]) {
/*  98*/                    continue;
                        }
/*  98*/                edges[k] = edges[--sizeEdges];
/*  98*/                break;
                    }

                }

/* 100*/        for (int l = 0; l < sizeNodes; l++) {
/* 100*/            if (nodes[l] != node) {
/* 101*/                continue;
                    }
/* 101*/            nodes[l] = nodes[--sizeNodes];
/* 101*/            break;
                }

/* 103*/        unplaceNode(node);
            }

            public void removeNode(String s) {
/* 107*/        Node node = findNode(s);
/* 107*/        if (node != null) {
/* 107*/            removeNode(node);
                }
            }

            public Edge addEdge(Edge edge) {
/* 111*/        if (member(edge)) {
/* 111*/            return edge;
                }
/* 112*/        Node node = addNode(edge.from);
/* 112*/        Node node1 = addNode(edge.to);
/* 113*/        node.addNeighbor(edge);
/* 113*/        node1.addNeighbor(edge);
/* 114*/        if (sizeEdges == allocatedEdges) {
/* 114*/            doubleEdgeArray();
                }
/* 115*/        return edges[sizeEdges++] = edge;
            }

            public Edge addEdge(Node node, Node node1, double d, String s) {
/* 119*/        return addEdge(new Edge(node, node1, d, s));
            }

            public Edge addEdge(Node node, Node node1, double d) {
/* 123*/        return addEdge(new Edge(node, node1, d, ""));
            }

            public Edge addEdge(Node node, Node node1, String s) {
/* 127*/        return addEdge(new Edge(node, node1, 0.0D, s));
            }

            public Edge addEdge(Node node, Node node1) {
/* 131*/        return addEdge(new Edge(node, node1, 0.0D, ""));
            }

            public Edge addEdge(String s, String s1, double d, String s2) {
/* 135*/        return addEdge(addNode(s), addNode(s1), d, s2);
            }

            public Edge addEdge(String s, String s1, double d) {
/* 139*/        return addEdge(s, s1, d, "");
            }

            public Edge addEdge(String s, String s1, String s2) {
/* 143*/        return addEdge(s, s1, 0.0D, s2);
            }

            public Edge addEdge(String s, String s1) {
/* 147*/        return addEdge(s, s1, 0.0D, "");
            }

            public void removeEdge(Edge edge) {
/* 151*/        edge.from.removeNeighbor(edge);
/* 151*/        edge.to.removeNeighbor(edge);
/* 152*/        for (int i = 0; i < sizeEdges; i++) {
/* 152*/            if (edges[i] == edge) {
/* 153*/                edges[i] = edges[--sizeEdges];
/* 153*/                return;
                    }
                }

            }

            public synchronized boolean refine() {
/* 158*/        return refine(barycenter);
            }

            private synchronized boolean refine(Barycenter barycenter1) {
/* 162*/        if (barycenter1.sizeNodes <= 4) {
/* 162*/            return false;
                }
/* 163*/        if (barycenter1.NW != null) {
/* 164*/            boolean flag = refine(barycenter1.NW);
/* 164*/            boolean flag1 = refine(barycenter1.NE);
/* 165*/            boolean flag2 = refine(barycenter1.SW);
/* 165*/            boolean flag3 = refine(barycenter1.SE);
/* 166*/            return flag || flag1 || flag2 || flag3;
                }
/* 169*/        barycenter1.NW = new Barycenter(barycenter1);
/* 169*/        barycenter1.NE = new Barycenter(barycenter1);
/* 170*/        barycenter1.SW = new Barycenter(barycenter1);
/* 170*/        barycenter1.SE = new Barycenter(barycenter1);
/* 171*/        for (int i = 0; i < barycenter1.sizeNodes; i++) {
/* 172*/            Node node = barycenter1.nodes[i];
/* 172*/            if (node.barycenter == barycenter1) {
/* 173*/                int k = 0;
/* 173*/                int l = 0;
/* 173*/                int i1 = 0;
/* 173*/                int j1 = 0;
/* 173*/                int k1 = 0;
/* 174*/                for (int l1 = 0; l1 < node.degree; l1++) {
/* 175*/                    Node node3 = node.neighbors[l1];
/* 176*/                    if (node3.barycenter != barycenter1) {
/* 177*/                        if (node3.barycenter == barycenter1.NW) {
/* 177*/                            k1 = Math.max(k1, ++k);
                                } else
/* 178*/                        if (node3.barycenter == barycenter1.NE) {
/* 178*/                            k1 = Math.max(k1, ++l);
                                } else
/* 179*/                        if (node3.barycenter == barycenter1.SW) {
/* 179*/                            k1 = Math.max(k1, ++i1);
                                } else
/* 180*/                        if (node3.barycenter == barycenter1.SE) {
/* 180*/                            k1 = Math.max(k1, ++j1);
                                }
                            }
                        }

/* 182*/                if (k1 > 0) {
/* 183*/                    if (k == k1) {
/* 183*/                        barycenter1.NW.addNode(node);
                            } else
/* 184*/                    if (l == k1) {
/* 184*/                        barycenter1.NE.addNode(node);
                            } else
/* 185*/                    if (i1 == k1) {
/* 185*/                        barycenter1.SW.addNode(node);
                            } else {
/* 186*/                        barycenter1.SE.addNode(node);
                            }
                        } else {
/* 189*/                    if (node.x < barycenter1.x) {
/* 190*/                        if (node.y < barycenter1.y) {
/* 190*/                            barycenter1.NW.addNode(node);
                                } else {
/* 190*/                            barycenter1.SW.addNode(node);
                                }
                            } else
/* 192*/                    if (node.y < barycenter1.y) {
/* 192*/                        barycenter1.NE.addNode(node);
                            } else {
/* 192*/                        barycenter1.SE.addNode(node);
                            }
/* 193*/                    for (int i2 = 0; i2 < node.degree; i2++) {
/* 194*/                        Node node4 = node.neighbors[i2];
/* 195*/                        if (node4.barycenter == barycenter1) {
/* 195*/                            node.barycenter.addNode(node4);
                                }
                            }

                        }
                    }
                }

/* 199*/        for (int j = 0; j < barycenter1.sizeEdges; j++) {
/* 200*/            Edge edge = barycenter1.edges[j];
/* 201*/            Node node1 = edge.from;
/* 201*/            Node node2 = edge.to;
/* 202*/            if (node1.barycenter != node2.barycenter) {
/* 203*/                node1.barycenter.addEdge(edge);
/* 203*/                node2.barycenter.addEdge(edge);
                    }
                }

/* 206*/        return true;
            }

            public void center(double d, double d1) {
/* 211*/        barycenter.translate(d - barycenter.x, d1 - barycenter.y);
            }

            public synchronized void reset() {
/* 215*/        barycenter = new Barycenter();
/* 216*/        for (int i = 0; i < sizeNodes; i++) {
/* 217*/            barycenter.addNode(nodes[i]);
                }

            }

            private void doubleNodeArray() {
/* 228*/        Node anode[] = new Node[allocatedNodes * 2];
/* 229*/        for (int i = 0; i < allocatedNodes; i++) {
/* 229*/            anode[i] = nodes[i];
                }

/* 230*/        nodes = anode;
/* 230*/        allocatedNodes = allocatedNodes * 2;
            }

            private void doubleEdgeArray() {
/* 234*/        Edge aedge[] = new Edge[allocatedEdges * 2];
/* 235*/        for (int i = 0; i < allocatedEdges; i++) {
/* 235*/            aedge[i] = edges[i];
                }

/* 236*/        edges = aedge;
/* 236*/        allocatedEdges = allocatedEdges * 2;
            }

}
