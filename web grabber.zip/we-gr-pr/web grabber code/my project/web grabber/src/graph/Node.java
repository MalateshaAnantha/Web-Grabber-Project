// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   Node.java

package graph;


// Referenced classes of package graph:
//            Edge, My, Barycenter

public class Node {

            private static int DEFAULT_ALLOCATION = 10;
            private int allocation;
            public String name;
            public int width;
            public int height;
            public double x;
            public double y;
            public boolean placed;
            public boolean fixed;
            public int degree;
            public Edge incidentEdges[];
            public Node neighbors[];
            public Barycenter barycenter;

            private void doubleArrays() {
/*  14*/        Edge aedge[] = new Edge[allocation * 2];
/*  15*/        for (int i = 0; i < allocation; i++) {
/*  16*/            aedge[i] = incidentEdges[i];
                }

/*  17*/        incidentEdges = aedge;
/*  18*/        Node anode[] = new Node[allocation * 2];
/*  19*/        for (int j = 0; j < allocation; j++) {
/*  19*/            anode[j] = neighbors[j];
                }

/*  20*/        neighbors = anode;
/*  20*/        allocation = allocation * 2;
            }

            public Node() {
/*  12*/        allocation = DEFAULT_ALLOCATION;
/*  26*/        name = "";
/*  29*/        placed = false;
/*  30*/        fixed = false;
/*  32*/        incidentEdges = new Edge[DEFAULT_ALLOCATION];
/*  33*/        neighbors = new Node[DEFAULT_ALLOCATION];
            }

            public Node(String s) {
/*  12*/        allocation = DEFAULT_ALLOCATION;
/*  26*/        name = "";
/*  29*/        placed = false;
/*  30*/        fixed = false;
/*  32*/        incidentEdges = new Edge[DEFAULT_ALLOCATION];
/*  33*/        neighbors = new Node[DEFAULT_ALLOCATION];
/*  39*/        name = s;
            }

            public Node(String s, int i, int j) {
/*  12*/        allocation = DEFAULT_ALLOCATION;
/*  26*/        name = "";
/*  29*/        placed = false;
/*  30*/        fixed = false;
/*  32*/        incidentEdges = new Edge[DEFAULT_ALLOCATION];
/*  33*/        neighbors = new Node[DEFAULT_ALLOCATION];
/*  41*/        name = s;
/*  41*/        width = i;
/*  41*/        height = j;
            }

            public Node(Node node) {
/*  12*/        allocation = DEFAULT_ALLOCATION;
/*  26*/        name = "";
/*  29*/        placed = false;
/*  30*/        fixed = false;
/*  32*/        incidentEdges = new Edge[DEFAULT_ALLOCATION];
/*  33*/        neighbors = new Node[DEFAULT_ALLOCATION];
/*  43*/        name = node.name;
/*  43*/        width = node.width;
/*  43*/        height = node.height;
/*  44*/        x = node.x;
/*  44*/        y = node.y;
/*  44*/        degree = node.degree;
/*  45*/        if ((allocation = node.allocation) > 0) {
/*  46*/            incidentEdges = new Edge[allocation];
/*  47*/            neighbors = new Node[allocation];
/*  48*/            for (int i = 0; i < degree; i++) {
/*  49*/                incidentEdges[i] = node.incidentEdges[i];
/*  50*/                neighbors[i] = node.neighbors[i];
                    }

                }
            }

            public Node(String s, Barycenter barycenter1) {
/*  12*/        allocation = DEFAULT_ALLOCATION;
/*  26*/        name = "";
/*  29*/        placed = false;
/*  30*/        fixed = false;
/*  32*/        incidentEdges = new Edge[DEFAULT_ALLOCATION];
/*  33*/        neighbors = new Node[DEFAULT_ALLOCATION];
/*  54*/        name = s;
/*  54*/        barycenter = barycenter1;
            }

            public boolean addNeighbor(Edge edge) {
/*  59*/        if (edge == null || this != edge.from && this != edge.to) {
/*  60*/            return false;
                }
/*  61*/        if (degree == allocation) {
/*  61*/            doubleArrays();
                }
/*  62*/        incidentEdges[degree] = edge;
/*  63*/        neighbors[degree++] = this != edge.from ? edge.from : edge.to;
/*  64*/        return true;
            }

            public boolean removeNeighbor(Node node) {
/*  68*/        for (int i = 0; i < degree; i++) {
/*  68*/            if (neighbors[i] == node) {
/*  69*/                incidentEdges[i] = incidentEdges[degree - 1];
/*  70*/                neighbors[i] = neighbors[degree - 1];
/*  71*/                degree = degree - 1;
/*  71*/                return true;
                    }
                }

/*  73*/        return false;
            }

            public boolean removeNeighbor(Edge edge) {
/*  77*/        for (int i = 0; i < degree; i++) {
/*  77*/            if (incidentEdges[i] == edge) {
/*  78*/                incidentEdges[i] = incidentEdges[degree - 1];
/*  79*/                neighbors[i] = neighbors[degree - 1];
/*  80*/                degree = degree - 1;
/*  80*/                return true;
                    }
                }

/*  82*/        return false;
            }

            public double distance(Node node) {
/*  85*/        return Math.sqrt(distanceSquared(node));
            }

            public synchronized double distanceSquared(Node node) {
/*  88*/        return My.square(x - node.x) + My.square(y - node.y);
            }

            public double distance(Edge edge) {
/*  91*/        return Math.sqrt(distanceSquared(edge));
            }

            public synchronized double distanceSquared(Edge edge) {
/*  94*/        double d = x - edge.from.x;
/*  94*/        double d1 = y - edge.from.y;
/*  95*/        double d2 = edge.to.x - edge.from.x;
/*  95*/        double d3 = edge.to.y - edge.from.y;
/*  96*/        double d4 = (d * d2 + d1 * d3) / (d2 * d2 + d3 * d3);
/*  97*/        if (d4 <= 0.0D) {
/*  97*/            return distanceSquared(edge.from);
                }
/*  98*/        if (d4 >= 1.0D) {
/*  98*/            return distanceSquared(edge.to);
                } else {
/*  99*/            return My.square(d - d4 * d2) + My.square(d1 - d4 * d3);
                }
            }

}
