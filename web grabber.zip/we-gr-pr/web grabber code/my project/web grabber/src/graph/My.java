// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   My.java

package graph;


public abstract class My {

            public static double square(double d) {
/*   5*/        return d * d;
            }

            public static int stringToInt(String s) {
/*   8*/        return Integer.valueOf(s).intValue();
            }

            public static int randomInt(int i, int j) {
/*  12*/        return i + (int)((double)((j - i) + 1) * Math.random());
            }

}
