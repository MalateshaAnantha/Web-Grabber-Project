// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   Edge.java

package graph;


// Referenced classes of package graph:
//            Node

public class Edge {

            public Node from;
            public Node to;
            public double restLength;
            public String label;
            public double labelWidth;
            public double labelHeight;
            public boolean placed;
            public boolean directed;

            public Edge(Node node, Node node1) {
/*   9*/        label = "";
/*  11*/        placed = false;
/*  12*/        directed = false;
/*  17*/        from = node;
/*  17*/        to = node1;
            }

            public Edge(Node node, Node node1, double d) {
/*   9*/        label = "";
/*  11*/        placed = false;
/*  12*/        directed = false;
/*  20*/        from = node;
/*  20*/        to = node1;
/*  20*/        restLength = d;
            }

            public Edge(Node node, Node node1, String s) {
/*   9*/        label = "";
/*  11*/        placed = false;
/*  12*/        directed = false;
/*  24*/        from = node;
/*  24*/        to = node1;
/*  24*/        label = s;
            }

            public Edge(Node node, Node node1, double d, String s) {
/*   9*/        label = "";
/*  11*/        placed = false;
/*  12*/        directed = false;
/*  28*/        from = node;
/*  28*/        to = node1;
/*  28*/        restLength = d;
/*  28*/        label = s;
            }

            public double length() {
/*  34*/        return Math.sqrt(lengthSquared());
            }

            public double lengthSquared() {
/*  36*/        return from.distanceSquared(to);
            }

            double distance(Node node) {
/*  38*/        return Math.sqrt(distanceSquared(node));
            }

            double distanceSquared(Node node) {
/*  40*/        return node.distanceSquared(this);
            }
}
