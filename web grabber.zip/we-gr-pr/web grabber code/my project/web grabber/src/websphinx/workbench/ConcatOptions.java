// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   ActionEditor.java

package websphinx.workbench;

import java.awt.*;
import rcm.awt.Constrain;
import rcm.awt.PopupDialog;
import rcm.util.Win;

// Referenced classes of package websphinx.workbench:
//            ActionFeatureArgs

class ConcatOptions extends PopupDialog {

            ActionFeatureArgs e;
            TextArea prolog;
            TextArea header;
            TextArea footer;
            TextArea divider;
            TextArea epilog;
            Button applyButton;
            Button okButton;
            Button cancelButton;

            public ConcatOptions(ActionFeatureArgs e) {
/* 437*/        super(Win.findFrame(e), "Concatenate Options", true);
/* 438*/        this.e = e;
/* 440*/        setLayout(new GridBagLayout());
/* 442*/        Constrain.add(this, new Label("Prolog:"), Constrain.labelLike(0, 0));
/* 444*/        Constrain.add(this, prolog = new TextArea(e.prolog, 3, 40), Constrain.areaLike(1, 0));
/* 447*/        Constrain.add(this, new Label("Page Header:"), Constrain.labelLike(0, 1));
/* 449*/        Constrain.add(this, header = new TextArea(e.header, 3, 40), Constrain.areaLike(1, 1));
/* 452*/        Constrain.add(this, new Label("Page Footer:"), Constrain.labelLike(0, 2));
/* 454*/        Constrain.add(this, footer = new TextArea(e.footer, 3, 40), Constrain.areaLike(1, 2));
/* 457*/        Constrain.add(this, new Label("Page Divider:"), Constrain.labelLike(0, 3));
/* 459*/        Constrain.add(this, divider = new TextArea(e.divider, 3, 40), Constrain.areaLike(1, 3));
/* 462*/        Constrain.add(this, new Label("Epilog:"), Constrain.labelLike(0, 4));
/* 464*/        Constrain.add(this, epilog = new TextArea(e.epilog, 3, 40), Constrain.areaLike(1, 4));
                Panel panel;
/* 468*/        Constrain.add(this, panel = new Panel(), Constrain.centered(Constrain.labelLike(0, 5, 2)));
/* 470*/        panel.add(applyButton = new Button("Apply"));
/* 471*/        panel.add(okButton = new Button("OK"));
/* 472*/        panel.add(cancelButton = new Button("Cancel"));
/* 474*/        pack();
            }

            void writeBack() {
/* 478*/        e.prolog = prolog.getText();
/* 479*/        e.header = header.getText();
/* 480*/        e.footer = footer.getText();
/* 481*/        e.divider = divider.getText();
/* 482*/        e.epilog = epilog.getText();
            }

            public boolean handleEvent(Event event) {
/* 487*/        if (event.id == 1001) {
/* 488*/            if (event.target == applyButton) {
/* 489*/                writeBack();
                    } else
/* 490*/            if (event.target == okButton) {
/* 491*/                writeBack();
/* 492*/                close();
                    } else
/* 494*/            if (event.target == cancelButton) {
/* 495*/                close();
                    } else {
/* 497*/                return super.handleEvent(event);
                    }
                } else {
/* 500*/            return super.handleEvent(event);
                }
/* 502*/        return true;
            }
}
