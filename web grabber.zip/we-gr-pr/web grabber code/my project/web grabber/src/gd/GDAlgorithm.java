// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   GDAlgorithm.java

package gd;

import graph.Graph;

public abstract class GDAlgorithm {

            public double springConstant;
            public double nodeCharge;
            protected static final double infinity = 1.7976931348623156E+306D;

           // public synchronized abstract double improveGraph(Graph graph);

            //public synchronized abstract double energy(Graph graph);

            public GDAlgorithm() {
/*   8*/        springConstant = 1.0D;
            }
}
