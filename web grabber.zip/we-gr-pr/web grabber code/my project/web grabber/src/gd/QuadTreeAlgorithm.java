// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   QuadTreeAlgorithm.java

package gd;

import graph.*;

// Referenced classes of package gd:
//            GDAlgorithm

public class QuadTreeAlgorithm extends GDAlgorithm {

            private double previousX[];
            private double previousY[];
            private double moveX[];
            private double moveY[];

            public QuadTreeAlgorithm(double d, double d1) {
/*   7*/        super.springConstant = d;
/*   7*/        super.nodeCharge = d1;
            }

            public synchronized double improveGraph(Graph graph) {
/*  13*/        if (graph.sizeNodes == 0) {
/*  13*/            return 0.0D;
                }
/*  14*/        if (previousX == null || previousX.length < graph.sizeNodes) {
/*  15*/            previousX = new double[graph.sizeNodes];
/*  15*/            previousY = new double[graph.sizeNodes];
/*  16*/            moveX = new double[graph.sizeNodes];
/*  16*/            moveY = new double[graph.sizeNodes];
                }
/*  18*/        for (int i = 0; i < graph.sizeNodes; i++) {
/*  19*/            previousX[i] = graph.nodes[i].x;
/*  19*/            previousY[i] = graph.nodes[i].y;
                }

/*  21*/        double d = energy(graph);
/*  22*/        double d1 = graph.barycenter.x;
/*  22*/        double d2 = graph.barycenter.y;
/*  23*/        improveBarycenter(graph.barycenter);
/*  24*/        for (int j = 0; j < graph.sizeNodes; j++) {
/*  25*/            moveX[j] = graph.nodes[j].x - previousX[j];
/*  26*/            moveY[j] = graph.nodes[j].y - previousY[j];
                }

/*  28*/        improveAll(graph, d);
/*  29*/        graph.center(d1, d2);
/*  30*/        return energy(graph) - d;
            }

            private synchronized void moveAll(Graph graph, double d) {
/*  34*/        for (int i = 0; i < graph.sizeNodes; i++) {
/*  35*/            graph.placeNode(graph.nodes[i], previousX[i] + d * moveX[i], previousY[i] + d * moveY[i]);
                }

            }

            private synchronized void improveAll(Graph graph, double d) {
/*  40*/        double d1 = energy(graph);
/*  41*/        moveAll(graph, -2D);
/*  42*/        double d2 = energy(graph);
/*  43*/        double d3 = (d1 + d2) - 2D * d;
/*  44*/        if (d3 == 0.0D) {
/*  44*/            moveAll(graph, 2D);
/*  44*/            return;
                }
/*  45*/        double d4 = (d1 - d2) / 2D;
/*  46*/        double d5 = -d4 / (2D * d3);
/*  47*/        moveAll(graph, d5 + 2D);
/*  48*/        if (energy(graph) >= d) {
/*  48*/            moveAll(graph, 1.0D - d5);
                }
            }

            public synchronized double energy(Graph graph) {
/*  51*/        return energy(graph.barycenter);
            }

            private synchronized double energy(Barycenter barycenter) {
/*  54*/        if (barycenter.NW == null) {
/*  54*/            return localEnergy(barycenter);
                } else {
/*  55*/            return groupEnergy(barycenter, 0.0D, 0.0D) + energy(barycenter.NW) + energy(barycenter.NE) + energy(barycenter.SW) + energy(barycenter.SE);
                }
            }

            private synchronized void improveBarycenter(Barycenter barycenter) {
/*  61*/        if (barycenter.sizeNodes == 0) {
/*  61*/            return;
                }
/*  62*/        Coords coords = groupForce(barycenter, 0.0D, 0.0D);
/*  63*/        double d = Math.sqrt(My.square(coords.x) + My.square(coords.y));
/*  64*/        if (d != 0.0D) {
/*  65*/            coords.x /= d;
/*  65*/            coords.y /= d;
/*  66*/            double d1 = groupEnergy(barycenter, 0.0D, 0.0D);
/*  67*/            double d2 = quadApprox(barycenter, d1, coords);
/*  68*/            if (d2 == 0.0D) {
/*  69*/                double d3 = coords.x;
/*  69*/                coords.x = coords.y;
/*  69*/                coords.y = -d3;
/*  70*/                d2 += quadApprox(barycenter, d1 + d2, coords);
/*  71*/                if (d2 == 0.0D) {
/*  72*/                    coords.x = Math.random();
/*  72*/                    coords.y = Math.random();
/*  73*/                    d2 += quadApprox(barycenter, d1 + d2, coords);
                        }
                    }
                }
/*  77*/        if (barycenter.NW != null) {
/*  78*/            improveBarycenter(barycenter.NW);
/*  78*/            improveBarycenter(barycenter.NE);
/*  78*/            improveBarycenter(barycenter.SW);
/*  78*/            improveBarycenter(barycenter.SE);
/*  77*/            return;
                } else {
/*  80*/            locallyImprove(barycenter);
/*  60*/            return;
                }
            }

            private synchronized Coords groupForce(Barycenter barycenter, double d, double d1) {
/*  85*/        if (barycenter.parent == null) {
/*  85*/            return new Coords(0.0D, 0.0D);
                } else {
/*  86*/            return repulsionForce(barycenter, d, d1).add(springForce(barycenter, d, d1));
                }
            }

            private synchronized double groupEnergy(Barycenter barycenter, double d, double d1) {
/*  91*/        if (barycenter.parent == null) {
/*  91*/            return 0.0D;
                } else {
/*  92*/            return repulsionEnergy(barycenter, d, d1) + springEnergy(barycenter, d, d1);
                }
            }

            private synchronized Coords springForce(Node node, Edge edge, double d, double d1) {
/*  99*/        if (!edge.from.placed || !edge.to.placed) {
/*  99*/            return new Coords(0.0D, 0.0D);
                }
/* 100*/        double d2 = edge.to.x - edge.from.x;
/* 100*/        double d3 = edge.to.y - edge.from.y;
/* 101*/        if (node == edge.from) {
/* 101*/            d2 -= d;
/* 101*/            d3 -= d1;
                } else {
/* 101*/            d2 += d;
/* 101*/            d3 += d1;
                }
/* 102*/        double d4 = Math.sqrt(My.square(d2) + My.square(d3));
/* 103*/        double d5 = d4 - edge.restLength;
/* 104*/        double d6 = (2D * super.springConstant * d5) / d4;
/* 105*/        if (node == edge.to) {
/* 105*/            d6 = -d6;
                }
/* 106*/        Coords coords = new Coords(d6 * d2, d6 * d3);
/* 107*/        if (edge.directed && d3 > edge.restLength) {
/* 108*/            coords.y -= (2D * super.springConstant * (d3 - edge.restLength)) / 2D;
                }
/* 109*/        return coords;
            }

            private synchronized Coords springForce(Barycenter barycenter, double d, double d1) {
/* 114*/        Coords coords = new Coords(0.0D, 0.0D);
/* 115*/        for (int i = 0; i < barycenter.sizeEdges; i++) {
/* 116*/            Edge edge = barycenter.edges[i];
/* 117*/            if (edge.from.barycenter == barycenter) {
/* 117*/                coords.add(springForce(edge.from, edge, d, d1));
                    } else {
/* 118*/                coords.add(springForce(edge.to, edge, d, d1));
                    }
                }

/* 120*/        return coords;
            }

            private synchronized double springEnergy(Edge edge, Node node, double d, double d1) {
/* 125*/        if (!edge.from.placed || !edge.to.placed) {
/* 125*/            return 0.0D;
                }
/* 126*/        double d2 = edge.to.x - edge.from.x;
/* 126*/        double d3 = edge.to.y - edge.from.y;
/* 127*/        if (node == edge.from) {
/* 127*/            d2 -= d;
/* 127*/            d3 -= d1;
                } else {
/* 127*/            d2 += d;
/* 127*/            d3 += d1;
                }
/* 128*/        double d4 = Math.sqrt(My.square(d2) + My.square(d3));
/* 129*/        double d5 = super.springConstant * My.square(d4 - edge.restLength);
/* 130*/        if (edge.directed && d3 > edge.restLength) {
/* 131*/            d5 -= (super.springConstant * My.square(d3 - edge.restLength)) / 2D;
                }
/* 132*/        return d5;
            }

            private synchronized double springEnergy(Barycenter barycenter, double d, double d1) {
/* 137*/        double d2 = 0.0D;
/* 138*/        new Coords(0.0D, 0.0D);
/* 139*/        for (int i = 0; i < barycenter.sizeEdges; i++) {
/* 140*/            Edge edge = barycenter.edges[i];
/* 141*/            if (edge.from.barycenter == barycenter) {
/* 141*/                d2 += springEnergy(edge, edge.from, d, d1);
                    } else {
/* 142*/                d2 += springEnergy(edge, edge.to, d, d1);
                    }
                }

/* 144*/        return d2;
            }

            private synchronized Coords repulsionForce(Barycenter barycenter, double d, double d1) {
/* 148*/        if (barycenter == null || barycenter.sizeNodes == 0 || barycenter.parent == null) {
/* 149*/            return new Coords(0.0D, 0.0D);
                }
/* 150*/        int i = barycenter.sizeNodes;
/* 150*/        int j = barycenter.parent.sizeNodes;
/* 151*/        if (i == j) {
/* 151*/            return new Coords(0.0D, 0.0D);
                }
/* 152*/        double d2 = (barycenter.parent.x * (double)j - barycenter.x * (double)i) / (double)(j - i);
/* 153*/        double d3 = (barycenter.parent.y * (double)j - barycenter.y * (double)i) / (double)(j - i);
/* 154*/        double d4 = (barycenter.x + d) - d2;
/* 154*/        double d5 = (barycenter.y + d1) - d3;
/* 155*/        if (d4 == 0.0D && d5 == 0.0D) {
/* 155*/            d4 = Math.random() - 0.5D;
/* 155*/            d5 = Math.random() - 0.5D;
                }
/* 156*/        double d6 = My.square((barycenter.width + barycenter.parent.width + 1.0D) * d4) + My.square((barycenter.height + barycenter.parent.height + 1.0D) * d5);
/* 158*/        double d7 = (My.square(super.nodeCharge) * (double)i * barycenter.degree * (double)j * barycenter.parent.degree) / Math.pow(d6, 1.5D);
/* 160*/        return (new Coords(d7 * d4, d7 * d5)).add(repulsionForce(barycenter.parent, (d * (double)i) / (double)j, (d1 * (double)i) / (double)j));
            }

            private synchronized double repulsionEnergy(Barycenter barycenter, double d, double d1) {
/* 166*/        if (barycenter == null || barycenter.sizeNodes == 0 || barycenter.parent == null) {
/* 167*/            return 0.0D;
                }
/* 168*/        int i = barycenter.sizeNodes;
/* 168*/        int j = barycenter.parent.sizeNodes;
/* 169*/        if (i == j) {
/* 169*/            return 0.0D;
                }
/* 170*/        double d2 = (barycenter.parent.x * (double)j - barycenter.x * (double)i) / (double)(j - i);
/* 171*/        double d3 = (barycenter.parent.y * (double)j - barycenter.y * (double)i) / (double)(j - i);
/* 172*/        double d4 = (barycenter.x + d) - d2;
/* 172*/        double d5 = (barycenter.y + d1) - d3;
/* 173*/        if (d4 == 0.0D && d5 == 0.0D) {
/* 173*/            d4 = Math.random() - 0.5D;
/* 173*/            d5 = Math.random() - 0.5D;
                }
/* 174*/        double d6 = My.square((barycenter.width + barycenter.parent.width + 1.0D) * d4) + My.square((barycenter.height + barycenter.parent.height + 1.0D) * d5);
/* 176*/        double d7 = My.square(super.nodeCharge) * (double)i * barycenter.degree * (double)j * barycenter.parent.degree;
/* 177*/        return d7 / Math.sqrt(d6) + repulsionEnergy(barycenter.parent, (d * (double)i) / (double)j, (d1 * (double)i) / (double)j);
            }

            private synchronized double quadApprox(Barycenter barycenter, double d, Coords coords) {
/* 183*/        double d1 = groupEnergy(barycenter, coords.x, coords.y);
/* 184*/        double d2 = groupEnergy(barycenter, -coords.x, -coords.y);
/* 185*/        double d3 = (d1 + d2) - 2D * d;
/* 186*/        double d4 = (d1 - d2) / 2D;
/* 187*/        double d5 = -d4 / (2D * d3);
/* 188*/        double d6 = groupEnergy(barycenter, d5 * coords.x, d5 * coords.y);
/* 189*/        if (d6 < d) {
/* 190*/            barycenter.translate(d5 * coords.x, d5 * coords.y);
/* 191*/            return d - d6;
                } else {
/* 193*/            return 0.0D;
                }
            }

            private synchronized double locallyImprove(Barycenter barycenter) {
/* 198*/        double d = localEnergy(barycenter);
/* 199*/        for (int i = 0; i < barycenter.sizeNodes; i++) {
/* 199*/            locallyImprove(barycenter.nodes[i]);
                }

/* 200*/        return localEnergy(barycenter) - d;
            }

            private synchronized double locallyImprove(Node node) {
/* 205*/        if (node.degree == 0 || node.fixed || !node.placed) {
/* 205*/            return 0.0D;
                }
/* 206*/        Coords coords = localForce(node, 0.0D, 0.0D);
/* 207*/        double d = Math.sqrt(My.square(coords.x) + My.square(coords.y));
/* 208*/        if (d == 0.0D) {
/* 208*/            return 0.0D;
                }
/* 209*/        coords.x /= d;
/* 209*/        coords.y /= d;
/* 210*/        double d1 = localEnergy(node, 0.0D, 0.0D);
/* 211*/        double d2 = quadApprox(node, d1, coords);
/* 212*/        if (d2 == 0.0D) {
/* 213*/            double d3 = coords.x;
/* 213*/            coords.x = coords.y;
/* 213*/            coords.y = -d3;
/* 214*/            d2 += quadApprox(node, d1 + d2, coords);
/* 215*/            if (d2 == 0.0D) {
/* 216*/                coords.x = Math.random();
/* 216*/                coords.y = Math.random();
/* 217*/                d2 += quadApprox(node, d1 + d2, coords);
                    }
                }
/* 220*/        return d2;
            }

            private synchronized Coords localForce(Node node, double d, double d1) {
/* 226*/        Coords coords = new Coords(0.0D, 0.0D);
/* 227*/        for (int i = 0; i < node.degree; i++) {
/* 228*/            coords.add(springForce(node, node.incidentEdges[i], d, d1));
                }

/* 229*/        Barycenter barycenter = node.barycenter;
/* 229*/        double d2 = barycenter.sizeNodes;
/* 229*/        if (d2 > 1.0D) {
/* 230*/            double d3 = (barycenter.x * d2 - node.x) / (d2 - 1.0D);
/* 231*/            double d4 = (barycenter.y * d2 - node.y) / (d2 - 1.0D);
/* 232*/            double d5 = (barycenter.width * d2 - (double)node.width) / (d2 - 1.0D);
/* 233*/            double d6 = (barycenter.height * d2 - (double)node.height) / (d2 - 1.0D);
/* 234*/            double d7 = (barycenter.degree * d2 - (double)node.degree) / (d2 - 1.0D);
/* 235*/            double d8 = (node.x + d) - d3;
/* 235*/            double d9 = (node.y + d1) - d4;
/* 236*/            if (d8 == 0.0D && d9 == 0.0D) {
/* 237*/                d8 = Math.random() - 0.5D;
/* 237*/                d9 = Math.random() - 0.5D;
                    }
/* 239*/            double d10 = My.square(((double)node.width + d5 + 1.0D) * d8) + My.square(((double)node.height + d6 + 1.0D) * d9);
/* 241*/            double d11 = (My.square(super.nodeCharge) * (d2 - 1.0D) * (double)node.degree * d7) / Math.pow(d10, 1.5D);
/* 243*/            coords.x += d11 * d8;
/* 243*/            coords.y += d11 * d9;
                }
/* 245*/        Coords coords1 = repulsionForce(node.barycenter, d / d2, d1 / d2);
/* 246*/        coords.x += coords1.x;
/* 246*/        coords.y += coords1.y;
/* 247*/        return coords;
            }

            private synchronized double localEnergy(Node node, double d, double d1) {
/* 253*/        double d2 = 0.0D;
/* 254*/        for (int i = 0; i < node.degree; i++) {
/* 255*/            d2 += springEnergy(node.incidentEdges[i], node, d, d1);
                }

/* 256*/        Barycenter barycenter = node.barycenter;
/* 256*/        double d3 = barycenter.sizeNodes;
/* 256*/        if (d3 > 1.0D) {
/* 257*/            double d4 = (barycenter.x * d3 - node.x) / (d3 - 1.0D);
/* 257*/            double d6 = (barycenter.y * d3 - node.y) / (d3 - 1.0D);
/* 258*/            double d7 = (barycenter.width * d3 - (double)node.width) / (d3 - 1.0D);
/* 259*/            double d8 = (barycenter.height * d3 - (double)node.height) / (d3 - 1.0D);
/* 260*/            double d9 = (barycenter.degree * d3 - (double)node.degree) / (d3 - 1.0D);
/* 261*/            double d10 = (node.x + d) - d4;
/* 261*/            double d11 = (node.y + d1) - d6;
/* 262*/            if (d10 == 0.0D && d11 == 0.0D) {
/* 262*/                return 1.7976931348623156E+306D;
                    }
/* 263*/            double d12 = My.square(((double)node.width + d7 + 1.0D) * d10) + My.square(((double)node.height + d8 + 1.0D) * d11);
/* 265*/            double d13 = My.square(super.nodeCharge) * (d3 - 1.0D) * (double)node.degree * d9;
/* 266*/            d2 += d13 / Math.sqrt(d12);
                }
/* 268*/        double d5 = repulsionEnergy(node.barycenter, d / d3, d1 / d3);
/* 269*/        return d2 + d5;
            }

            private synchronized double localEnergy(Barycenter barycenter) {
/* 274*/        double d = 0.0D;
/* 275*/        for (int i = 0; i < barycenter.sizeNodes; i++) {
/* 275*/            d += localEnergy(barycenter.nodes[i], 0.0D, 0.0D);
                }

/* 276*/        return d;
            }

            private synchronized double quadApprox(Node node, double d, Coords coords) {
/* 281*/        double d1 = localEnergy(node, coords.x, coords.y);
/* 282*/        double d2 = localEnergy(node, -coords.x, -coords.y);
/* 283*/        double d3 = (d1 + d2) - 2D * d;
/* 284*/        double d4 = (d1 - d2) / 2D;
/* 285*/        double d5 = -d4 / (2D * d3);
/* 286*/        double d6 = localEnergy(node, d5 * coords.x, d5 * coords.y);
/* 288*/        if (d6 < d) {
/* 289*/            double d7 = node.x + d5 * coords.x;
/* 290*/            double d8 = node.y + d5 * coords.y;
/* 291*/            node.barycenter.moveNode(node, d7, d8);
/* 291*/            node.x = d7;
/* 291*/            node.y = d8;
/* 292*/            return d - d6;
                } else {
/* 294*/            return 0.0D;
                }
            }
}
