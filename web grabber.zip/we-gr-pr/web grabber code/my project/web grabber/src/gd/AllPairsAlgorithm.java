// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   AllPairsAlgorithm.java

package gd;

import graph.*;

// Referenced classes of package gd:
//            GDAlgorithm

public class AllPairsAlgorithm extends GDAlgorithm {

            public AllPairsAlgorithm(double d, double d1) {
/*   7*/        super.springConstant = d;
/*   7*/        super.nodeCharge = d1;
            }

            public synchronized double energy(Graph graph) {
/*  11*/        double d = 0.0D;
/*  12*/        for (int i = 0; i < graph.sizeNodes; i++) {
/*  12*/            d += energy(graph, graph.nodes[i], 0.0D, 0.0D) / 2D;
                }

/*  13*/        return d;
            }

            public synchronized double improveGraph(Graph graph) {
/*  18*/        if (graph.sizeNodes == 0) {
/*  18*/            return 0.0D;
                }
/*  19*/        double d = graph.barycenter.x;
/*  19*/        double d1 = graph.barycenter.y;
/*  19*/        boolean flag = false;
/*  20*/        for (int i = 0; i < graph.sizeNodes; i++) {
/*  20*/            flag |= graph.nodes[i].fixed;
                }

/*  21*/        double d2 = 0.0D;
/*  22*/        for (int j = 0; j < graph.sizeNodes; j++) {
/*  22*/            d2 += improveNode(graph, graph.nodes[j]);
                }

/*  23*/        if (!flag) {
/*  23*/            graph.center(d, d1);
                }
/*  24*/        return d2;
            }

            private synchronized Coords repulsionForce(Node node, Node node1, double d, double d1) {
/*  29*/        double d2 = (node.x + d) - node1.x;
/*  29*/        double d3 = (node.y + d1) - node1.y;
/*  30*/        double d4 = My.square((double)(node.width + node1.width + 1) * d2) + My.square((double)(node.height + node1.height + 1) * d3);
/*  32*/        if (d4 == 0.0D) {
/*  33*/            return new Coords(Math.random() - 0.5D, Math.random() - 0.5D);
                } else {
/*  34*/            double d5 = (My.square(super.nodeCharge) * (double)node.degree * (double)node1.degree) / Math.pow(d4, 1.5D);
/*  36*/            return new Coords(d5 * d2, d5 * d3);
                }
            }

            private synchronized double repulsionEnergy(Node node, Node node1, double d, double d1) {
/*  41*/        double d2 = (node.x + d) - node1.x;
/*  41*/        double d3 = (node.y + d1) - node1.y;
/*  42*/        double d4 = My.square((double)(node.width + node1.width + 1) * d2) + My.square((double)(node.height + node1.height + 1) * d3);
/*  44*/        if (d4 == 0.0D) {
/*  44*/            return 1.7976931348623156E+306D;
                } else {
/*  45*/            return (My.square(super.nodeCharge) * (double)node.degree * (double)node1.degree) / Math.sqrt(d4);
                }
            }

            private synchronized Coords springForce(Node node, Edge edge, double d, double d1) {
/*  51*/        double d2 = edge.to.x - edge.from.x;
/*  51*/        double d3 = edge.to.y - edge.from.y;
/*  52*/        if (node == edge.to) {
/*  52*/            d2 += d;
/*  52*/            d3 += d1;
                } else {
/*  52*/            d2 -= d;
/*  52*/            d3 -= d1;
                }
/*  53*/        double d4 = Math.sqrt(My.square(d2) + My.square(d3));
/*  54*/        double d5 = d4 - edge.restLength;
/*  55*/        double d6 = (2D * super.springConstant * d5) / d4;
/*  56*/        if (node == edge.to) {
/*  56*/            d6 = -d6;
                }
/*  57*/        Coords coords = new Coords(d6 * d2, d6 * d3);
/*  58*/        if (edge.directed && d3 > edge.restLength) {
/*  59*/            coords.y -= (2D * super.springConstant * (d3 - edge.restLength)) / 2D;
                }
/*  60*/        return coords;
            }

            private synchronized double springEnergy(Edge edge, Node node, double d, double d1) {
/*  65*/        double d2 = edge.to.x - edge.from.x;
/*  65*/        double d3 = edge.to.y - edge.from.y;
/*  66*/        if (node == edge.to) {
/*  66*/            d2 += d;
/*  66*/            d3 += d1;
                } else {
/*  66*/            d2 -= d;
/*  66*/            d3 -= d1;
                }
/*  67*/        double d4 = Math.sqrt(My.square(d2) + My.square(d3));
/*  68*/        double d5 = super.springConstant * My.square(d4 - edge.restLength);
/*  69*/        if (edge.directed && d3 > edge.restLength) {
/*  70*/            d5 -= (super.springConstant * My.square(d3 - edge.restLength)) / 2D;
                }
/*  71*/        return d5;
            }

            private synchronized Coords force(Graph graph, Node node, double d, double d1) {
/*  76*/        Coords coords = new Coords(0.0D, 0.0D);
/*  77*/        for (int i = 0; i < graph.sizeNodes; i++) {
/*  78*/            if (graph.nodes[i] != node) {
/*  78*/                coords.add(repulsionForce(node, graph.nodes[i], d, d1));
                    }
                }

/*  79*/        for (int j = 0; j < node.degree; j++) {
/*  80*/            coords.add(springForce(node, node.incidentEdges[j], d, d1));
                }

/*  81*/        return coords;
            }

            private synchronized double energy(Graph graph, Node node, double d, double d1) {
/*  86*/        double d2 = 0.0D;
/*  87*/        for (int i = 0; i < graph.sizeNodes; i++) {
/*  88*/            if (graph.nodes[i] != node) {
/*  88*/                d2 += repulsionEnergy(node, graph.nodes[i], d, d1);
                    }
                }

/*  89*/        for (int j = 0; j < node.degree; j++) {
/*  90*/            d2 += springEnergy(node.incidentEdges[j], node, d, d1);
                }

/*  91*/        return d2;
            }

            private synchronized double improveNode(Graph graph, Node node) {
/*  96*/        if (node.degree == 0 || node.fixed || !node.placed) {
/*  96*/            return 0.0D;
                }
/*  97*/        Coords coords = force(graph, node, 0.0D, 0.0D);
/*  98*/        double d = Math.sqrt(My.square(coords.x) + My.square(coords.y));
/*  99*/        if (d == 0.0D) {
/*  99*/            return 0.0D;
                } else {
/* 100*/            coords.x /= d;
/* 100*/            coords.y /= d;
/* 101*/            double d1 = energy(graph, node, 0.0D, 0.0D);
/* 102*/            double d2 = quadApprox(graph, node, d1, coords);
/* 103*/            double d3 = coords.x;
/* 103*/            coords.x = coords.y;
/* 103*/            coords.y = -d3;
/* 104*/            d2 += quadApprox(graph, node, d1 + d2, coords);
/* 105*/            coords.x = Math.random();
/* 105*/            coords.y = Math.random();
/* 106*/            d2 += quadApprox(graph, node, d1 + d2, coords);
/* 107*/            graph.placeNode(node, node.x, node.y);
/* 108*/            return d2;
                }
            }

            private synchronized double quadApprox(Graph graph, Node node, double d, Coords coords) {
/* 113*/        double d1 = energy(graph, node, coords.x, coords.y);
/* 114*/        double d2 = energy(graph, node, -coords.x, -coords.y);
/* 115*/        double d3 = (d1 + d2) - 2D * d;
/* 116*/        double d4 = (d1 - d2) / 2D;
/* 117*/        double d5 = -d4 / (2D * d3);
/* 118*/        double d6 = energy(graph, node, d5 * coords.x, d5 * coords.y);
/* 119*/        if (d6 < d) {
/* 120*/            graph.placeNode(node, node.x + d5 * coords.x, node.y + d5 * coords.y);
/* 121*/            return d - d6;
                } else {
/* 123*/            return 0.0D;
                }
            }
}
