// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   TreeNode.java

package symantec.itools.awt;

import java.awt.Color;
import java.awt.Image;

public class TreeNode {

            TreeNode sibling;
            TreeNode child;
            TreeNode parent;
            String text;
            Color color;
            Image collapsedImage;
            Image expandedImage;
            int numberOfChildren;
            Object dataObject;
            int depth;
            boolean isExpanded;

            void setDepth(int depth) {
/*  70*/        this.depth = depth;
            }

            public int getDepth() {
/*  79*/        return depth;
            }

            public void setColor(Color color) {
/*  89*/        this.color = color;
            }

            public Color getColor() {
/*  98*/        return color;
            }

            public boolean isExpanded() {
/* 108*/        return isExpanded;
            }

            public boolean isExpandable() {
/* 118*/        return child != null;
            }

            public void expand() {
/* 126*/        if (isExpandable()) {
/* 128*/            isExpanded = true;
                }
            }

            public void collapse() {
/* 137*/        isExpanded = false;
            }

            public void toggle() {
/* 146*/        if (isExpanded) {
/* 148*/            collapse();
                } else
/* 150*/        if (isExpandable()) {
/* 152*/            expand();
                }
            }

            public Image getImage() {
/* 162*/        return !isExpanded || expandedImage == null ? collapsedImage : expandedImage;
            }

            public void setExpandedImage(Image image) {
/* 175*/        expandedImage = image;
            }

            public void setCollapsedImage(Image image) {
/* 186*/        collapsedImage = image;
            }

            public String getText() {
/* 196*/        return text;
            }

            public void setText(String s) {
/* 206*/        text = new String(s);
            }

            public Object getDataObject() {
/* 217*/        return dataObject;
            }

            public void setDataObject(Object theObject) {
/* 228*/        dataObject = theObject;
            }

            public TreeNode getParent() {
/* 239*/        return parent;
            }

            public TreeNode getChild() {
/* 250*/        return child;
            }

            public TreeNode getSibling() {
/* 261*/        return sibling;
            }

            public TreeNode(String text) {
/*  39*/        this(text, null, null);
            }

            public TreeNode(String text, Image collapsedImage, Image expandedImage) {
/*  52*/        depth = -1;
/*  52*/        isExpanded = false;
/*  53*/        this.text = text;
/*  54*/        color = null;
/*  55*/        sibling = null;
/*  56*/        child = null;
/*  57*/        this.collapsedImage = collapsedImage;
/*  58*/        this.expandedImage = expandedImage;
/*  59*/        numberOfChildren = 0;
/*  60*/        dataObject = null;
            }
}
