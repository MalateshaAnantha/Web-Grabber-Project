// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(5) braces fieldsfirst noctor nonlb space lnc 
// Source File Name:   TreeView.java

package symantec.itools.awt;

import java.awt.*;
import java.io.PrintStream;
import java.util.Vector;

// Referenced classes of package symantec.itools.awt:
//            InvalidTreeNodeException, TreeNode

public class TreeView extends Panel {

            public static final int CHILD = 0;
            public static final int NEXT = 1;
            public static final int LAST = 2;
            /**
             * @deprecated Field SEL_CHANGED is deprecated
             */
            public static final int SEL_CHANGED = 1006;
            private TreeNode rootNode;
            private TreeNode selectedNode;
            private TreeNode topVisibleNode;
            protected Scrollbar verticalScrollBar;
            int sbVPosition;
            int sbVWidth;
            long sbVTimer;
            private boolean sbVShow;
            protected int count;
            protected int viewCount;
            protected Scrollbar horizontalScrollBar;
            int sbHPosition;
            int sbHHeight;
            private int sbHSize;
            private int newWidth;
            private boolean sbHShow;
            private int sbHLineIncrement;
            private int viewHeight;
            private int viewWidth;
            private int viewWidest;
            int cellSize;
            int clickSize;
            int imageInset;
            int textInset;
            int textBaseLine;
            private FontMetrics fm;
            protected boolean isSun1_1;
            protected Image im1;
            protected Graphics g1;
            private Vector e;
            private Vector v;
            protected boolean redrawTriggered;
            protected boolean treeChanged;
            protected boolean hasFocus;

            public synchronized void clear() {
/* 197*/        rootNode = selectedNode = null;
/* 198*/        count = 0;
/* 199*/        viewCount = 0;
/* 200*/        triggerRedraw();
            }

            public void setTreeStructure(String s[]) {
/* 213*/        rootNode = selectedNode = null;
/* 215*/        try {
/* 215*/            parseTreeStructure(s);
                }
/* 215*/        catch (InvalidTreeNodeException e) {
/* 221*/            System.out.println(e);
                }
/* 224*/        triggerRedraw();
            }

            public String[] getTreeStructure() {
/* 241*/        if (rootNode == null) {
/* 241*/            return null;
                }
/* 242*/        Vector nodesVector = new Vector(count);
/* 243*/        rootNode.depth = 0;
/* 244*/        vectorize(rootNode, false, nodesVector);
/* 247*/        int numNodes = nodesVector.size();
/* 248*/        String treeStructure[] = new String[numNodes];
/* 249*/        for (int i = 0; i < numNodes; i++) {
/* 251*/            TreeNode thisNode = (TreeNode)nodesVector.elementAt(i);
/* 254*/            String treeString = "";
/* 255*/            for (int numBlanks = 0; numBlanks < thisNode.depth; numBlanks++) {
/* 256*/                treeString += " ";
                    }

/* 259*/            treeString += thisNode.text;
/* 262*/            treeStructure[i] = treeString;
                }

/* 265*/        return treeStructure;
            }

            /**
             * @deprecated Method setFgHilite is deprecated
             */

            public void setFgHilite(Color color) {
            }

            /**
             * @deprecated Method getFgHilite is deprecated
             */

            public Color getFgHilite() {
/* 287*/        return Color.black;
            }

            /**
             * @deprecated Method setBgHilite is deprecated
             */

            public void setBgHilite(Color color) {
            }

            /**
             * @deprecated Method getBgHilite is deprecated
             */

            public Color getBgHilite() {
/* 305*/        return Color.white;
            }

            public Object[] getSelectedObjects() {
/* 319*/        if (selectedNode == null) {
/* 320*/            return null;
                } else {
/* 322*/            TreeNode selectedObjects[] = new TreeNode[1];
/* 323*/            selectedObjects[0] = selectedNode;
/* 325*/            return selectedObjects;
                }
            }

            public void insert(TreeNode newNode, TreeNode relativeNode, int position) {
/* 378*/        if (newNode == null || relativeNode == null) {
/* 379*/            return;
                }
/* 381*/        if (!exists(relativeNode)) {
/* 382*/            return;
                }
/* 384*/        switch (position) {
/* 387*/        case 0: // '\0'
/* 387*/            addChild(newNode, relativeNode);
                    break;

/* 391*/        case 1: // '\001'
/* 391*/            addSibling(newNode, relativeNode, false);
                    break;

/* 395*/        case 2: // '\002'
/* 395*/            addSibling(newNode, relativeNode, true);
                    break;

/* 400*/        default:
/* 400*/            return;
                }
            }

            public TreeNode getRootNode() {
/* 412*/        return rootNode;
            }

            public int getCount() {
/* 420*/        return count;
            }

            public int getViewCount() {
/* 429*/        return viewCount;
            }

            boolean viewable(TreeNode node) {
/* 441*/        for (int i = 0; i < viewCount; i++) {
/* 443*/            if (node == v.elementAt(i)) {
/* 445*/                return true;
                    }
                }

/* 449*/        return false;
            }

            boolean viewable(String s) {
/* 461*/        if (s == null) {
/* 463*/            return false;
                }
/* 466*/        for (int i = 0; i < viewCount; i++) {
/* 468*/            TreeNode tn = (TreeNode)v.elementAt(i);
/* 470*/            if (tn.text != null && s.equals(tn.text)) {
/* 474*/                return true;
                    }
                }

/* 479*/        return false;
            }

            public boolean exists(TreeNode node) {
/* 490*/        recount();
/* 492*/        for (int i = 0; i < count; i++) {
/* 494*/            if (node == e.elementAt(i)) {
/* 496*/                return true;
                    }
                }

/* 500*/        return false;
            }

            public boolean exists(String s) {
/* 511*/        recount();
/* 513*/        if (s == null) {
/* 515*/            return false;
                }
/* 518*/        for (int i = 0; i < count; i++) {
/* 520*/            TreeNode tn = (TreeNode)e.elementAt(i);
/* 522*/            if (tn.text != null && s.equals(tn.text)) {
/* 526*/                return true;
                    }
                }

/* 531*/        return false;
            }

            public void append(TreeNode newNode) {
/* 544*/        if (rootNode == null) {
/* 546*/            rootNode = newNode;
/* 547*/            selectedNode = rootNode;
/* 548*/            count = 1;
/* 549*/            triggerRedraw();
                } else {
/* 553*/            addSibling(newNode, rootNode, true);
                }
            }

            void addChild(TreeNode newNode, TreeNode relativeNode) {
/* 559*/        if (relativeNode.child == null) {
/* 561*/            relativeNode.child = newNode;
/* 562*/            newNode.parent = relativeNode;
/* 563*/            count++;
/* 564*/            triggerRedraw();
                } else {
/* 568*/            addSibling(newNode, relativeNode.child, true);
                }
/* 571*/        relativeNode.numberOfChildren++;
            }

            void addSibling(TreeNode newNode, TreeNode siblingNode) {
/* 576*/        addSibling(newNode, siblingNode, true);
            }

            void addSibling(TreeNode newNode, TreeNode siblingNode, boolean asLastSibling) {
/* 581*/        if (asLastSibling) {
                    TreeNode tempNode;
/* 584*/            for (tempNode = siblingNode; tempNode.sibling != null; tempNode = tempNode.sibling) { }
/* 588*/            tempNode.sibling = newNode;
                } else {
/* 593*/            newNode.sibling = siblingNode.sibling;
/* 595*/            siblingNode.sibling = newNode;
                }
/* 599*/        newNode.parent = siblingNode.parent;
/* 601*/        count++;
/* 602*/        triggerRedraw();
            }

            public TreeNode remove(String s) {
/* 614*/        recount();
/* 616*/        for (int i = 0; i < count; i++) {
/* 618*/            TreeNode tn = (TreeNode)e.elementAt(i);
/* 620*/            if (tn.text != null && s.equals(tn.text)) {
/* 624*/                remove(tn);
/* 625*/                triggerRedraw();
/* 626*/                return tn;
                    }
                }

/* 631*/        return null;
            }

            public void removeSelected() {
/* 641*/        if (selectedNode != null) {
/* 643*/            remove(selectedNode);
                }
            }

            public void remove(TreeNode node) {
/* 656*/        if (!exists(node)) {
/* 658*/            return;
                }
/* 661*/        if (node == selectedNode) {
/* 663*/            int index = v.indexOf(selectedNode);
/* 665*/            if (index == -1) {
/* 667*/                index = e.indexOf(selectedNode);
                    }
/* 670*/            if (index > viewCount - 1) {
/* 672*/                index = viewCount - 1;
                    }
/* 675*/            if (index > 0) {
/* 677*/                changeSelection((TreeNode)v.elementAt(index - 1));
                    } else
/* 679*/            if (viewCount > 1) {
/* 681*/                changeSelection((TreeNode)v.elementAt(1));
                    }
                }
/* 686*/        if (node.parent != null) {
/* 688*/            if (node.parent.child == node) {
/* 690*/                if (node.sibling != null) {
/* 692*/                    node.parent.child = node.sibling;
                        } else {
/* 696*/                    node.parent.child = null;
/* 697*/                    node.parent.collapse();
                        }
                    } else {
                        TreeNode tn;
/* 702*/                for (tn = node.parent.child; tn.sibling != node; tn = tn.sibling) { }
/* 709*/                if (node.sibling != null) {
/* 711*/                    tn.sibling = node.sibling;
                        } else {
/* 715*/                    tn.sibling = null;
                        }
                    }
                } else
/* 721*/        if (node == rootNode) {
/* 723*/            if (node.sibling == null) {
/* 725*/                rootNode = null;
                    } else {
/* 729*/                rootNode = node.sibling;
                    }
                } else {
                    TreeNode tn;
/* 734*/            for (tn = rootNode; tn.sibling != node; tn = tn.sibling) { }
/* 741*/            if (node.sibling != null) {
/* 743*/                tn.sibling = node.sibling;
                    } else {
/* 747*/                tn.sibling = null;
                    }
                }
/* 752*/        recount();
/* 753*/        triggerRedraw();
            }

            public void printTree(TreeNode node) {
/* 765*/        if (node == null) {
/* 767*/            return;
                } else {
/* 770*/            System.out.println(node.text);
/* 771*/            printTree(node.child);
/* 772*/            printTree(node.sibling);
/* 773*/            return;
                }
            }

            private void recount() {
/* 778*/        count = 0;
/* 779*/        e = new Vector();
/* 781*/        if (rootNode != null) {
/* 783*/            rootNode.depth = 0;
/* 784*/            traverse(rootNode);
                }
            }

            private void traverse(TreeNode node) {
/* 790*/        count++;
/* 791*/        e.addElement(node);
/* 793*/        if (node.child != null) {
/* 795*/            node.child.depth = node.depth + 1;
/* 796*/            traverse(node.child);
                }
/* 798*/        if (node.sibling != null) {
/* 800*/            node.sibling.depth = node.depth;
/* 801*/            traverse(node.sibling);
                }
            }

            private void resetVector() {
/* 811*/        v = new Vector(count);
/* 812*/        viewWidest = 30;
/* 814*/        if (count < 1) {
/* 816*/            viewCount = 0;
/* 817*/            return;
                } else {
/* 820*/            rootNode.depth = 0;
/* 821*/            vectorize(rootNode, true, v);
/* 822*/            viewCount = v.size();
/* 823*/            return;
                }
            }

            private void vectorize(TreeNode node, boolean respectExpanded, Vector nodeVector) {
/* 830*/        if (node == null) {
/* 831*/            return;
                }
/* 833*/        nodeVector.addElement(node);
/* 835*/        if (!respectExpanded && node.child != null || node.isExpanded()) {
/* 837*/            node.child.depth = node.depth + 1;
/* 838*/            vectorize(node.child, respectExpanded, nodeVector);
                }
/* 841*/        if (node.sibling != null) {
/* 843*/            node.sibling.depth = node.depth;
/* 844*/            vectorize(node.sibling, respectExpanded, nodeVector);
                }
            }

            private void debugVector() {
/* 850*/        int vSize = v.size();
/* 852*/        for (int i = 0; i < count; i++) {
/* 854*/            TreeNode node = (TreeNode)v.elementAt(i);
/* 855*/            System.out.println(node.text);
                }

            }

            public synchronized boolean handleEvent(Event event) {
/* 867*/        if (event.target == verticalScrollBar) {
/* 869*/            if (sbVPosition != verticalScrollBar.getValue()) {
/* 871*/                sbVPosition = verticalScrollBar.getValue();
/* 872*/                scrolled();
                    }
/* 874*/            return true;
                }
/* 876*/        if (event.target == horizontalScrollBar) {
/* 878*/            if (sbHPosition != horizontalScrollBar.getValue()) {
/* 880*/                sbHPosition = horizontalScrollBar.getValue();
/* 881*/                repaint();
                    }
/* 883*/            return true;
                } else {
/* 886*/            return super.handleEvent(event);
                }
            }

            public boolean mouseDown(Event event, int x, int y) {
/* 910*/        requestFocus();
/* 915*/        int index = y / cellSize + sbVPosition;
/* 918*/        if (index > viewCount - 1) {
/* 919*/            return true;
                }
/* 921*/        TreeNode oldNode = selectedNode;
/* 922*/        TreeNode newNode = (TreeNode)v.elementAt(index);
/* 923*/        int newDepth = newNode.getDepth();
/* 925*/        changeSelection(newNode);
/* 928*/        Rectangle toggleBox = new Rectangle((cellSize * newDepth + cellSize / 4) - sbHPosition, (index - sbVPosition) * cellSize + clickSize / 2, clickSize, clickSize);
/* 932*/        if (toggleBox.inside(x, y)) {
/* 934*/            newNode.toggle();
/* 936*/            triggerRedraw();
                } else
/* 941*/        if (newNode == oldNode && event.clickCount == 2) {
/* 945*/            sendActionEvent();
                }
/* 954*/        return true;
            }

            public boolean keyDown(Event event, int key) {
/* 975*/        int index = v.indexOf(selectedNode);
/* 977*/        switch (key) {
/* 981*/        case 13: // '\r'
/* 981*/            sendActionEvent();
/* 982*/            requestFocus();
/* 983*/            break;

/* 985*/        case 1006: 
/* 985*/            if (event.controlDown()) {
/* 987*/                if (sbHPosition > 0) {
/* 989*/                    horizontalScrollBar.setValue(Math.max(sbHPosition -= sbHLineIncrement, 0));
/* 990*/                    repaint();
                        }
/* 992*/                break;
                    }
/* 995*/            if (selectedNode.isExpanded()) {
/* 997*/                selectedNode.toggle();
/* 998*/                triggerRedraw();
/* 999*/                break;
                    }
                    // fall through

/*1004*/        case 1004: 
/*1004*/            if (index > 0) {
/*1006*/                index--;
/*1007*/                changeSelection((TreeNode)v.elementAt(index));
/*1008*/                requestFocus();
                    }
/*1010*/            break;

/*1012*/        case 1007: 
/*1012*/            if (event.controlDown()) {
/*1014*/                int max = horizontalScrollBar.getMaximum() - (isSun1_1 ? size().width - sbVWidth : 0);
/*1015*/                if (sbHShow && sbHPosition < max) {
/*1017*/                    horizontalScrollBar.setValue(Math.min(sbHPosition += sbHLineIncrement, max));
/*1018*/                    repaint();
                        }
/*1020*/                break;
                    }
/*1023*/            if (selectedNode.isExpandable() && !selectedNode.isExpanded()) {
/*1025*/                selectedNode.toggle();
/*1027*/                triggerRedraw();
/*1028*/                break;
                    }
/*1031*/            if (!selectedNode.isExpandable()) {
/*1033*/                break;
                    }
                    // fall through

/*1037*/        case 1005: 
/*1037*/            if (index < viewCount - 1) {
/*1039*/                index++;
/*1040*/                changeSelection((TreeNode)v.elementAt(index));
/*1041*/                requestFocus();
                    }
                    break;

/*1047*/        default:
/*1047*/            return false;
                }
/*1049*/        return true;
            }

            public boolean gotFocus(Event e, Object what) {
/*1057*/        hasFocus = true;
/*1058*/        if (selectedNode != null && v != null) {
/*1059*/            drawNodeText(selectedNode, (v.indexOf(selectedNode) - sbVPosition) * cellSize, true);
                }
/*1060*/        return true;
            }

            public boolean focusLost(Event e, Object what) {
/*1065*/        hasFocus = false;
/*1066*/        if (selectedNode != null && v != null) {
/*1067*/            drawNodeText(selectedNode, (v.indexOf(selectedNode) - sbVPosition) * cellSize, true);
                }
/*1068*/        return true;
            }

            protected void sendActionEvent() {
/*1078*/        deliverEvent(new Event(this, 1001, selectedNode.getText()));
            }

            public TreeNode getSelectedNode() {
/*1087*/        return selectedNode;
            }

            public String getSelectedText() {
/*1097*/        if (selectedNode == null) {
/*1098*/            return null;
                } else {
/*1100*/            return selectedNode.getText();
                }
            }

            protected void changeSelection(TreeNode node) {
/*1105*/        if (node == selectedNode) {
/*1106*/            return;
                }
/*1108*/        TreeNode oldNode = selectedNode;
/*1109*/        selectedNode = node;
/*1110*/        drawNodeText(oldNode, (v.indexOf(oldNode) - sbVPosition) * cellSize, true);
/*1111*/        drawNodeText(node, (v.indexOf(node) - sbVPosition) * cellSize, true);
/*1114*/        int index = v.indexOf(selectedNode);
/*1124*/        if (index < sbVPosition) {
/*1126*/            sbVPosition--;
/*1127*/            verticalScrollBar.setValue(sbVPosition);
/*1128*/            triggerRedraw();
/*1129*/            return;
                }
/*1132*/        if (index >= sbVPosition + (viewHeight - cellSize / 2) / cellSize) {
/*1134*/            sbVPosition++;
/*1135*/            verticalScrollBar.setValue(sbVPosition);
/*1136*/            triggerRedraw();
/*1137*/            return;
                } else {
/*1140*/            repaint();
/*1141*/            return;
                }
            }

            public synchronized void update(Graphics g) {
/*1167*/        paint(g);
            }

            public void paint(Graphics g) {
/*1184*/        Dimension d = size();
/*1185*/        if (d.width != viewWidth || d.height != viewHeight) {
/*1186*/            triggerRedraw();
                }
/*1188*/        if (redrawTriggered) {
/*1191*/            redraw(g);
                }
/*1203*/        g.translate(-sbHPosition, 0);
/*1205*/        if (sbVShow && sbHShow) {
/*1207*/            g.setColor(Color.lightGray);
/*1208*/            g.fillRect((sbHPosition + d.width) - sbVWidth, d.height - sbHHeight, sbVWidth, sbHHeight);
                }
/*1210*/        g.clipRect(sbHPosition, 0, d.width - sbVWidth, d.height - sbHHeight);
/*1211*/        g.drawImage(im1, 0, 0, this);
/*1212*/        g.setColor(Color.black);
/*1213*/        g.drawRect(sbHPosition, 0, d.width - sbVWidth - 1, d.height - sbHHeight - 1);
            }

            public void redraw() {
/*1224*/        triggerRedraw();
            }

            public void redraw(Graphics g) {
/*1229*/        boolean recalculate = treeChanged;
/*1230*/        int inRectCount = 0;
/*1232*/        redrawTriggered = false;
/*1233*/        treeChanged = false;
/*1235*/        Dimension d = size();
/*1237*/        if (recalculate) {
/*1239*/            resetVector();
/*1241*/            newWidth = compWidth(g);
/*1243*/            inRectCount = (d.height - sbHHeight) / cellSize;
/*1244*/            if (viewCount > inRectCount) {
/*1247*/                sbVShow = true;
/*1248*/                sbVWidth = verticalScrollBar.preferredSize().width;
                    } else {
/*1252*/                sbVShow = false;
/*1253*/                sbVWidth = 0;
/*1254*/                sbVPosition = 0;
                    }
/*1257*/            if (newWidth > d.width - sbVWidth) {
/*1260*/                sbHShow = true;
/*1261*/                sbHHeight = horizontalScrollBar.preferredSize().height;
                    } else {
/*1265*/                sbHShow = false;
/*1266*/                sbHHeight = 0;
/*1267*/                sbHPosition = 0;
                    }
                }
/*1272*/        drawTree();
/*1274*/        if (recalculate) {
/*1275*/            verticalScrollBar.setValues(sbVPosition, inRectCount, 0, viewCount - (isSun1_1 ? 0 : inRectCount));
/*1276*/            verticalScrollBar.setPageIncrement(inRectCount - 1);
/*1278*/            horizontalScrollBar.setValues(sbHPosition, d.width - sbVWidth, 0, sbHSize - (isSun1_1 ? 0 : d.width - sbVWidth));
/*1279*/            horizontalScrollBar.setPageIncrement(d.width - sbVWidth);
/*1280*/            horizontalScrollBar.setLineIncrement(sbHLineIncrement);
/*1282*/            if (sbVShow) {
/*1284*/                verticalScrollBar.reshape(d.width - sbVWidth, 0, sbVWidth, d.height - sbHHeight);
/*1285*/                verticalScrollBar.show();
                    } else {
/*1289*/                verticalScrollBar.hide();
                    }
/*1292*/            if (sbHShow) {
/*1294*/                horizontalScrollBar.reshape(0, d.height - sbHHeight, d.width - sbVWidth, sbHHeight);
/*1295*/                horizontalScrollBar.show();
                    } else {
/*1299*/                horizontalScrollBar.hide();
                    }
                }
            }

            private int compWidth(Graphics gg) {
/*1306*/        int size = 0;
/*1307*/        Font f = getFont();
/*1312*/        if (f == null) {
/*1314*/            f = new Font("TimesRoman", 0, 13);
/*1315*/            gg.setFont(f);
/*1316*/            setFont(f);
                }
/*1319*/        fm = gg.getFontMetrics();
/*1321*/        for (int i = 0; i < v.size(); i++) {
/*1323*/            TreeNode node = (TreeNode)v.elementAt(i);
/*1324*/            int textOffset = ((node.depth + 1) * cellSize + cellSize + textInset) - (node.getImage() != null ? 0 : 12);
/*1325*/            if (size < textOffset + fm.stringWidth(node.text) + 6) {
/*1326*/                size = textOffset + fm.stringWidth(node.text) + 6;
                    }
                }

/*1329*/        return size;
            }

            public void drawTree() {
/*1336*/        Dimension d = size();
/*1338*/        if (d.width != viewWidth || d.height != viewHeight || g1 == null || sbHSize != newWidth) {
/*1341*/            im1 = createImage(Math.max(sbHSize = newWidth, d.width), d.height);
/*1342*/            if (g1 != null) {
/*1343*/                g1.dispose();
                    }
/*1345*/            g1 = im1.getGraphics();
/*1346*/            viewWidth = d.width;
/*1347*/            viewHeight = d.height;
                }
/*1350*/        Font f = getFont();
/*1353*/        if (f == null) {
/*1355*/            f = new Font("TimesRoman", 0, 13);
/*1356*/            g1.setFont(f);
/*1357*/            setFont(f);
                }
/*1361*/        if (f != null && g1.getFont() == null) {
/*1364*/            g1.setFont(f);
                }
/*1367*/        fm = g1.getFontMetrics();
/*1368*/        g1.setColor(getBackground());
/*1369*/        g1.fillRect(0, 0, im1.getWidth(this), d.height);
/*1372*/        int lastOne = sbVPosition + viewHeight / cellSize + 1;
/*1374*/        if (lastOne > viewCount) {
/*1376*/            lastOne = viewCount;
                }
/*1379*/        TreeNode outerNode = null;
/*1380*/        if (!v.isEmpty()) {
/*1381*/            outerNode = (TreeNode)v.elementAt(sbVPosition);
                }
/*1382*/        for (int i = sbVPosition; i < lastOne; i++) {
/*1384*/            TreeNode node = (TreeNode)v.elementAt(i);
/*1385*/            int x = cellSize * (node.depth + 1);
/*1386*/            int y = (i - sbVPosition) * cellSize;
/*1389*/            g1.setColor(getForeground());
/*1392*/            if (node.sibling != null) {
/*1394*/                int k = v.indexOf(node.sibling) - i;
/*1396*/                if (k > lastOne) {
/*1398*/                    k = lastOne;
                        }
/*1401*/                drawDotLine(x - cellSize / 2, y + cellSize / 2, x - cellSize / 2, y + cellSize / 2 + k * cellSize);
                    }
/*1406*/            for (int m = 0; m < i; m++) {
/*1408*/                TreeNode sib = (TreeNode)v.elementAt(m);
/*1410*/                if (sib.sibling == node && m < sbVPosition) {
/*1412*/                    drawDotLine(x - cellSize / 2, 0, x - cellSize / 2, y + cellSize / 2);
                        }
                    }

/*1418*/            if (node.isExpanded()) {
/*1420*/                drawDotLine(x + cellSize / 2, (y + cellSize) - 2, x + cellSize / 2, y + cellSize + cellSize / 2);
                    }
/*1424*/            g1.setColor(getForeground());
/*1425*/            drawDotLine(x - cellSize / 2, y + cellSize / 2, x + cellSize / 2, y + cellSize / 2);
/*1429*/            if (node.isExpandable()) {
/*1431*/                g1.setColor(getBackground());
/*1432*/                g1.fillRect(cellSize * node.depth + cellSize / 4, y + clickSize / 2, clickSize, clickSize);
/*1433*/                g1.setColor(getForeground());
/*1434*/                g1.drawRect(cellSize * node.depth + cellSize / 4, y + clickSize / 2, clickSize, clickSize);
/*1436*/                g1.drawLine(cellSize * node.depth + cellSize / 4 + 2, y + cellSize / 2, (cellSize * node.depth + cellSize / 4 + clickSize) - 2, y + cellSize / 2);
/*1439*/                if (!node.isExpanded()) {
/*1441*/                    g1.drawLine(cellSize * node.depth + cellSize / 2, y + clickSize / 2 + 2, cellSize * node.depth + cellSize / 2, (y + clickSize / 2 + clickSize) - 2);
                        }
                    }
/*1447*/            Image nodeImage = node.getImage();
/*1449*/            if (nodeImage != null) {
/*1451*/                g1.drawImage(nodeImage, x + imageInset, y, this);
                    }
/*1455*/            if (node.text != null) {
/*1457*/                drawNodeText(node, y, true);
                    }
/*1460*/            if (outerNode.depth > node.depth) {
/*1461*/                outerNode = node;
                    }
                }

/*1465*/        if (outerNode != null) {
/*1469*/            while ((outerNode = outerNode.parent) != null)  {
/*1469*/                if (outerNode.sibling != null) {
/*1470*/                    drawDotLine(cellSize * (outerNode.depth + 1) - cellSize / 2, 0, cellSize * (outerNode.depth + 1) - cellSize / 2, d.height);
                        }
                    }
                }
            }

            void drawNodeText(TreeNode node, int yPosition, boolean eraseBackground) {
/*1478*/        int depth = node.depth;
/*1480*/        Image nodeImage = node.getImage();
/*1481*/        int textOffset = ((depth + 1) * cellSize + cellSize + textInset) - (nodeImage != null ? 0 : 12);
                Color fg;
                Color bg;
/*1501*/        if (node.color != null) {
/*1502*/            fg = isLight(node.color) ? Color.black : Color.white;
/*1503*/            bg = node.color;
                } else {
/*1506*/            fg = getForeground();
/*1507*/            bg = getBackground();
                }
/*1510*/        if (eraseBackground) {
/*1512*/            g1.setColor(bg);
/*1513*/            g1.fillRect(textOffset - 1, yPosition + 1, fm.stringWidth(node.text) + 4, cellSize - 1);
                }
/*1516*/        if (node == selectedNode) {
/*1518*/            g1.setColor(getForeground());
/*1519*/            g1.drawRect(textOffset - 1, yPosition + 1, fm.stringWidth(node.text) + 3, cellSize - 2);
/*1520*/            repaint(Math.max(0, textOffset - 1 - sbHPosition), yPosition + 1, fm.stringWidth(node.text) + 4, cellSize - 1);
                }
/*1522*/        g1.setColor(fg);
/*1523*/        g1.drawString(node.text, textOffset, (yPosition + cellSize) - textBaseLine);
            }

            private boolean isLight(Color c) {
/*1527*/        int r = c.getRed();
/*1528*/        int g = c.getGreen();
/*1529*/        int b = c.getBlue();
/*1531*/        int min = r >= g ? g : r;
/*1532*/        if (b < min) {
/*1533*/            min = b;
                }
/*1535*/        return min > 128;
            }

            private void drawDotLine(int x0, int y0, int x1, int y1) {
/*1540*/        if (y0 == y1) {
/*1542*/            for (int i = x0; i < x1; i += 2) {
/*1544*/                g1.drawLine(i, y0, i, y1);
                    }

                } else {
/*1549*/            for (int i = y0; i < y1; i += 2) {
/*1551*/                g1.drawLine(x0, i, x1, i);
                    }

                }
            }

            private void parseTreeStructure(String tempStructure[]) throws InvalidTreeNodeException {
/*1559*/        for (int i = 0; i < tempStructure.length; i++) {
/*1561*/            String entry = tempStructure[i];
/*1562*/            int indentLevel = findLastPreSpace(entry);
/*1564*/            if (indentLevel == -1) {
/*1565*/                throw new InvalidTreeNodeException();
                    }
/*1567*/            TreeNode node = new TreeNode(entry.trim());
/*1568*/            node.setDepth(indentLevel);
/*1570*/            if (rootNode == null) {
/*1572*/                if (indentLevel != 0) {
/*1573*/                    throw new InvalidTreeNodeException();
                        }
/*1575*/                append(node);
                    } else {
                        TreeNode currentNode;
/*1579*/                for (currentNode = rootNode; currentNode.sibling != null; currentNode = currentNode.sibling) { }
/*1583*/                for (int j = 1; j < indentLevel; j++) {
/*1585*/                    int numberOfChildren = currentNode.numberOfChildren;
/*1586*/                    TreeNode tempNode = null;
/*1588*/                    if (numberOfChildren > 0) {
/*1590*/                        for (tempNode = currentNode.child; tempNode.sibling != null; tempNode = tempNode.sibling) { }
                            }
/*1596*/                    if (tempNode == null) {
/*1597*/                        break;
                            }
/*1597*/                    currentNode = tempNode;
                        }

/*1602*/                int diff = indentLevel - currentNode.getDepth();
/*1604*/                if (diff > 1) {
/*1605*/                    throw new InvalidTreeNodeException();
                        }
/*1607*/                if (diff == 1) {
/*1608*/                    insert(node, currentNode, 0);
                        } else {
/*1610*/                    insert(node, currentNode, 1);
                        }
                    }
                }

            }

            private int findLastPreSpace(String s) {
/*1617*/        int length = s.length();
/*1621*/        if (s.charAt(0) != ' ' && s.charAt(0) != '\t') {
/*1623*/            return 0;
                }
/*1626*/        for (int i = 1; i < length; i++) {
/*1628*/            if (s.charAt(i) != ' ' && s.charAt(i) != '\t') {
/*1630*/                return i;
                    }
                }

/*1634*/        return -1;
            }

            public synchronized Dimension preferredSize() {
/*1647*/        return new Dimension(175, 125);
            }

            public synchronized Dimension minimumSize() {
/*1659*/        return new Dimension(50, 50);
            }

            public void setLayout(LayoutManager layoutmanager) {
            }

            void scrolled() {
/*1785*/        redrawTriggered = true;
/*1786*/        repaint();
            }

            protected void triggerRedraw() {
/*1791*/        redrawTriggered = true;
/*1792*/        treeChanged = true;
/*1793*/        repaint();
            }

            public TreeView() {
/* 164*/        sbVPosition = 0;
/* 164*/        sbVTimer = -1L;
/* 164*/        sbVShow = false;
/* 164*/        count = 0;
/* 164*/        viewCount = 0;
/* 164*/        sbHPosition = 0;
/* 164*/        sbHHeight = 0;
/* 164*/        newWidth = 0;
/* 164*/        sbHShow = false;
/* 164*/        sbHLineIncrement = 4;
/* 164*/        viewHeight = 300;
/* 164*/        viewWidth = 300;
/* 164*/        viewWidest = 0;
/* 164*/        cellSize = 16;
/* 164*/        clickSize = 8;
/* 164*/        imageInset = 3;
/* 164*/        textInset = 6;
/* 164*/        textBaseLine = 3;
/* 164*/        g1 = null;
/* 164*/        redrawTriggered = false;
/* 164*/        treeChanged = false;
/* 164*/        hasFocus = false;
/* 165*/        super.setLayout(null);
/* 166*/        verticalScrollBar = new Scrollbar(1);
/* 167*/        verticalScrollBar.hide();
/* 168*/        add(verticalScrollBar);
/* 169*/        horizontalScrollBar = new Scrollbar(0);
/* 170*/        horizontalScrollBar.hide();
/* 171*/        add(horizontalScrollBar);
/* 176*/        isSun1_1 = true;
            }

            public TreeView(TreeNode head) {
/* 186*/        this();
/* 187*/        selectedNode = rootNode = head;
/* 188*/        count = 1;
            }
}
